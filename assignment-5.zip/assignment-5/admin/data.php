<?php
 
 $server = "localhost";
 $user = "root";
 $password = "";
 $db = "dash1";

 $con = mysqli_connect($server,$user,$password,$db);

 if(!$con){
    //     echo 'connection successfully';
    // }else{
        die(mysqli_error($con));
    }

?>