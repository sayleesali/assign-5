
<!-- registration form start -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
<style>
form{
    margin-top:30px;
    margin-left:350px;

}

</style>


</head>

<body>
<form action="#" method="POST" enctype="multipart/form-data">
<?php
  include 'data.php';

  $id = $_GET['id'];

$selectquery="select * from video where id=$id";
$query = mysqli_query($con,$selectquery);
$result = mysqli_fetch_assoc($query);


if(isset($_POST['submit'])){
  
    $id = $_GET['id'];

    $file_name = $_FILES['file']['name'];
    $file_type = $_FILES['file']['type'];
    $temp_name = $_FILES['file']['tmp_name'];
    $file_size = $_FILES['file']['size'];
    $file_destination = "video/".$file_name;

    if(move_uploaded_file($temp_name,$file_destination)){
    $updatequery = "update video set id=$id,name='$file_name' where id=$id";
     
       if(mysqli_query($con,$updatequery)){
           $success = "video updeted successfully.";
           header('location:addvideo.php');
       }else{
           $failed = "something went wrong??";
       }
    }else{
       $msz = "please select a video to upload..!";
    }
}

?>

<div class="col-lg-6">
    <div class="card">
                          
            <div class="card-body card-block">
    <div class="form-group">
    <label for="company" class="form-control-label">Upload Video</label>
        <input type="file" id="company" class="form-control" name="file"><video src="./video/<?php echo $result['name']; ?>" width='100px' height='100px'>
    </div>
    <?php if(isset($success)){
        ?>
        <div class="alert alert-success">
            <?php echo $success; ?>
    </div>
    <?php
    }
    ?>
    <?php if(isset($failed)){
        ?>
        <div class="alert alert-danger">
            <?php echo $failed; ?>
    </div>
    <?php } ?>
    <?php if(isset($msz)){
        ?>
        <div class="alert alert-danger">
            <?php echo $msz; ?>
    </div>
       <?php } ?>                      
   
<button type="submit" class="btn btn-lg btn-info btn-block" name="submit">Submit</button>
</div>
</div>

</div>

</form>


    
      <!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>
                                                 
</body>
</html>
<!-- registration form end -->








