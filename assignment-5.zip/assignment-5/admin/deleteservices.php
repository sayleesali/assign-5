<?php
include 'data.php';

$id = $_GET['id'];

$deletequery="delete from services where id=$id";

$query = mysqli_query($con,$deletequery);

if($query){
    ?>
    <script>
        alert('deleted successfully');
        </script>
        <?php
        header('location:addservices.php');
}else{
    ?>
    <script>
        alert('not deleted');
        </script>
        <?php
}
?>