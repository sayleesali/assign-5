
    <?php
 include 'data.php';
if(isset($_POST['submit'])){
   
    // $name = $_FILES['file'];
    // echo "<pre>";
    // print_r($name);
    // exit();
     $file_name = $_FILES['file']['name'];
     $file_type = $_FILES['file']['type'];
     $temp_name = $_FILES['file']['tmp_name'];
     $file_size = $_FILES['file']['size'];
     $file_destination = "video/".$file_name;

     if(move_uploaded_file($temp_name,$file_destination)){
        $insertquery = "insert into video(name)values('$file_name')";
        if(mysqli_query($con,$insertquery)){
            $success = "video uploaded successfully.";
        }else{
            $failed = "something went wrong??";
        }
     }else{
        $msz = "please select a video to upload..!";
     }
 }
?>

<!-- registration form start -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
<style>
form{
    margin-top:30px;
    margin-left:350px;

}

</style>


</head>

<body>
<form action="addvideo.php" method="POST" enctype="multipart/form-data">
<div class="col-lg-6">
    <div class="card">
                          
            <div class="card-body card-block">
    <div class="form-group">
        <label for="company" class="form-control-label">Upload Video</label>
        <input type="file" id="company" class="form-control" name="file">
    </div>
    <?php if(isset($success)){
        ?>
        <div class="alert alert-success">
            <?php echo $success; ?>
    </div>
    <?php
    }
    ?>
    <?php if(isset($failed)){
        ?>
        <div class="alert alert-danger">
            <?php echo $failed; ?>
    </div>
    <?php } ?>
    <?php if(isset($msz)){
        ?>
        <div class="alert alert-danger">
            <?php echo $msz; ?>
    </div>
       <?php } ?>                         

<button type="submit" class="btn btn-lg btn-info btn-block" name="submit">Submit</button>
</div>
</div>

</div>

</form>


    
      <!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>
                                                 
</body>
</html>
<!-- registration form end -->
<?php
include 'selectvideo.php';
?>