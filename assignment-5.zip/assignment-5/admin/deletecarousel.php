<?php
include 'data.php';

$id = $_GET['id'];

$deletequery="delete from carousel where id=$id";

$query = mysqli_query($con,$deletequery);

if($query){
    ?>
    <script>
        alert('deleted successfully');
        </script>
        <?php
        header('location:addcarousel.php');
}else{
    ?>
    <script>
        alert('not deleted');
        </script>
        <?php
}
?>