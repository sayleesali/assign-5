
<!-- registration form start -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
<style>
form{
    margin-top:30px;
    margin-left:350px;

}

</style>


</head>

<body>
<form action="#" method="POST" enctype="multipart/form-data">
<?php
  include 'data.php';

  $id = $_GET['id'];

$selectquery="select * from team1 where id=$id";
$query = mysqli_query($con,$selectquery);
$result = mysqli_fetch_assoc($query);


if(isset($_POST['submit'])){
  
    $id = $_GET['id'];

    $image = $_FILES['image'];
    // print_r($_FILES['ifile']);
    $img_loc=$_FILES['image']['tmp_name'];
    $img_name = $_FILES['image']['name'];
    $img_des = "team1Image/".$img_name;
    move_uploaded_file($img_loc,'team1Image/'.$img_name);

  $title = $_POST['title'];
  $profession = $_POST['profession'];


 $updatequery = "update team1 set id=$id,image='$img_name',title='$title',profession='$profession' where id=$id";
 
$query=mysqli_query($con,$updatequery);

if($query){
  ?>
  <script>
    alert('updated successfully');
   </script>
    <?php
    
}else{
  ?>
  <script>
    alert('no updated');
    </script>
    <?php
  }
 
}
?>

<div class="col-lg-6">
    <div class="card">
                          
            <div class="card-body card-block">
    <div class="form-group">
        <label for="company" class=" form-control-label">Upload Image</label>
        <input type="file" id="company" class="form-control" name="image"><img src="./team1Image/<?php echo $result['image']; ?>" width='100px' height='100px'>
    </div>
                             
    <div class="form-group">
        <label for="vat" class=" form-control-label">Title</label>
        <input type="text" id="vat" class="form-control" name="title" value="<?php echo $result['title']; ?>">
    </div>

    <div class="form-group">
    <label for="street" class=" form-control-label">Profession</label>
<input type="text" id="street" class="form-control" name="profession" value="<?php echo $result['profession']; ?>">
</div>

                                
<!-- <div class="form-group">
    <button type="submit" name="submit">Submit</button>
</div> -->
<button type="submit" class="btn btn-lg btn-info btn-block" name="submit">Submit</button>
</div>
</div>

</div>

</form>


    
      <!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>
                                                 
</body>
</html>
<!-- registration form end -->








