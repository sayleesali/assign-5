<?php
include 'data.php';

$id = $_GET['id'];

$sql1 = "SELECT * FROM blog WHERE id = {$id}";
$result = mysqli_query($con,$sql1) or die("query failed : select");
$row = mysqli_fetch_assoc($result);

// echo "<pre>";
// print_r($row);
// echo "</pre>";
// die();
unlink("blogImage/".$row['image']);

$deletequery="delete from blog where id=$id";

$query = mysqli_query($con,$deletequery);

if($query){
    ?>
    <script>
        alert('deleted successfully');
        </script>
        <?php
        header('location:addblog.php');
}else{
    ?>
    <script>
        alert('not deleted');
        </script>
        <?php
}
?>