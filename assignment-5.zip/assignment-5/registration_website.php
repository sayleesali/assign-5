<!-- registration form php code start -->
<?php

$success = 0;
$user = 0;

if($_SERVER['REQUEST_METHOD']=='POST'){
include 'admin\data.php';

$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$dob = $_POST['dob'];

$sql = "select * from registration where username='$username'";

$result = mysqli_query($con,$sql);

if($result){
    $num=mysqli_num_rows($result);
    if($num>0){
        // echo "user already exist";
        $user=1;
    }else{
         $sql = "insert into registration(username,password,email,name,phone,dob)values('$username','$password','$email','$name','$phone','$dob')";
          $result=mysqli_query($con,$sql);

if($result){
//    echo "signup successfully";
        $success=1;
        header('location:login_website.php');
 }else{
    die(mysqli_error($con));
       }
     }
  }
}
?>
<!-- registration form php code end -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/lib/chosen/chosen.min.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <style>
        .card{
            background-color:#010140;
        }
        .content{
            margin-left:350px;
        }
        i{
            color:yellow;
        }
        label{
            color:yellow;
        }
        button{
            margin-left:170px;
            color:#010140;
        }
        h4{
            margin-left:150px;
            color:white;
            font-weight:bold;
        }
        h2{
            margin-left:480px;
            font-weight:bold;
        }
        </style>
</head>
<body>
<?php
if($user){
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>ohh no sorry!</strong> user already exist
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
?>

<?php
if($success){
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>success</strong> you are successfully signup.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
?>

 <h2>Registration Form</h2>
    <form action="registration_website.php" method="POST">
<div class="content">
            <div class="animated fadeIn">
           
                    <div class="col-xs-6 col-sm-6 mt-5">
                        <div class="card">
                        <h4>Create An Account</h4>
                            <div class="card-body card-block">
                                <div class="form-group">
                                    <label class=" form-control-label">Name:</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-male"></i></div>
                                        <input type="text" class="form-control" name="name" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Email:</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                                        <input type="email" class="form-control" name="email" required>
                                    </div>
                                  
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Password:</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-lock"></i></div>
                                        <input type="password" class="form-control" name="password" required>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Username:</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-user"></i></div>
                                        <input type="text" class="form-control" name="username" required>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Mobile No.</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-phone"></i></div>
                                        <input type="text" class="form-control" maxlength="10" name="phone" required>
                                    </div>
                                  
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Date Of Birth</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                                        <input type="date" class="form-control" name="dob" required>
                                    </div>
                                  
                                </div>
                                <button type="submit" class="btn btn-warning" name="register">Registration</button>
                            </div>
                        </div>
                     
    </form>



<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/lib/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
</script>



            </body>
</html>

